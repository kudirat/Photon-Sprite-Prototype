﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PulseEffect : MonoBehaviour
{
    private Light lightSrc;
    public float pulse = 1f; 
    private float timer;

    void Start()
    {
        lightSrc = GetComponent<Light>();
    }
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > pulse)
        {
            timer = 0;
            lightSrc.enabled = !lightSrc.enabled;
        }
    }
}
